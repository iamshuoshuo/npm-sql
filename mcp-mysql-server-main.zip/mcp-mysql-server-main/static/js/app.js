// 全局变量
const API_URL = 'http://localhost:5000/api';
let dbSchema = [];
let currentChart = null;

// DOM元素
const chatHistory = document.getElementById('chatHistory');
const queryForm = document.getElementById('queryForm');
const queryInput = document.getElementById('queryInput');
const executeQuery = document.getElementById('executeQuery');
const schemaAccordion = document.getElementById('schemaAccordion');
const refreshSchema = document.getElementById('refreshSchema');
const dbHost = document.getElementById('dbHost');
const dbName = document.getElementById('dbName');
const dbUser = document.getElementById('dbUser');
// 创建模态框对象
const resultModalElement = document.getElementById('resultModal');
const resultContent = document.getElementById('resultContent');
const viewLastResults = document.getElementById('viewLastResults');

// 创建模态框对象
const resultModal = {
    show: function(results) {
        console.log('Showing modal');
        resultModalElement.style.display = 'block';
        document.body.classList.add('modal-open');
        document.body.style.overflow = 'hidden';
        document.body.style.paddingRight = '15px';
        
        // 显示传入的结果
        if (results) {
            displayResults(results);
        }

        // 设置焦点到模态框
        resultModalElement.focus();
    },
    hide: function() {
        console.log('Hiding modal');
        resultModalElement.style.display = 'none';
        document.body.classList.remove('modal-open');
        document.body.style.overflow = '';
        document.body.style.paddingRight = '';

        // 将焦点返回到查询输入框
        queryInput.focus();
    }
};

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    // 加载配置
    loadConfig();

    // 加载表结构
    loadSchema();

    // 添加事件监听器
    queryForm.addEventListener('submit', handleQuerySubmit);
    refreshSchema.addEventListener('click', loadSchema);

    // 添加查看上次结果按钮事件
    if (viewLastResults) {
        viewLastResults.addEventListener('click', () => {
            if (lastQueryResults) {
                resultModal.show();
            }
        });
    }

    // 添加模态框关闭事件
    const closeModal = document.getElementById('closeModal');
    const closeModalBtn = document.getElementById('closeModalBtn');

    if (closeModal) {
        closeModal.addEventListener('click', () => {
            resultModal.hide();
        });
    }

    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', () => {
            resultModal.hide();
        });
    }

    // 点击模态框外部关闭
    if (resultModalElement) {
        resultModalElement.addEventListener('click', (e) => {
            if (e.target === resultModalElement) {
                resultModal.hide();
            }
        });
    }

    // 添加键盘事件监听
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && resultModalElement.style.display === 'block') {
            resultModal.hide();
        }
    });

    // 添加图表类型切换事件监听
    document.querySelectorAll('[data-chart-type]').forEach(button => {
        button.addEventListener('click', (e) => {
            const type = e.target.dataset.chartType;
            const currentResults = resultContent.querySelector('table')?.dataset.results;
            if (currentResults) {
                try {
                    const results = JSON.parse(currentResults);
                    initChart(results, type);
                } catch (error) {
                    console.error('解析结果数据失败:', error);
                }
            }
        });
    });
});

// 加载配置
async function loadConfig() {
    try {
        const response = await fetch(`${API_URL}/config`);
        const data = await response.json();

        if (data.success) {
            const config = data.config;
            dbHost.textContent = config.host;
            dbName.textContent = config.database;
            dbUser.textContent = config.user;
        }
    } catch (error) {
        console.error('加载配置失败:', error);
        addSystemMessage('无法加载数据库配置。请检查API服务器是否运行。');
    }
}

// 加载表结构
async function loadSchema() {
    try {
        // 显示加载中
        schemaAccordion.innerHTML = '<div class="text-center p-3"><div class="spinner-border" role="status"></div> 加载中...</div>';

        const response = await fetch(`${API_URL}/schema`);
        const data = await response.json();

        if (data.success) {
            dbSchema = data.schema;
            renderSchema(dbSchema);
        } else {
            schemaAccordion.innerHTML = `<div class="alert alert-danger">加载表结构失败: ${data.error}</div>`;
        }
    } catch (error) {
        console.error('加载表结构失败:', error);
        schemaAccordion.innerHTML = `<div class="alert alert-danger">加载表结构失败: ${error.message}</div>`;
    }
}

// 渲染表结构
function renderSchema(schema) {
    if (!schema || schema.length === 0) {
        schemaAccordion.innerHTML = '<div class="alert alert-info">没有找到表结构信息</div>';
        return;
    }

    let html = '';

    // 添加搜索框
    html += `
        <div class="schema-search">
            <input type="text" class="form-control" id="schemaSearch" placeholder="搜索表名..." />
        </div>
    `;

    // 添加表分类标签
    html += `
        <div class="schema-tabs">
            <div class="schema-tab active" data-filter="all">所有表 (${schema.length})</div>
            <div class="schema-tab" data-filter="data">数据表</div>
            <div class="schema-tab" data-filter="system">系统表</div>
        </div>
    `;

    // 添加表列表
    html += '<div class="schema-tables">';

    schema.forEach((table, index) => {
        const tableId = `table-${index}`;
        const headingId = `heading-${index}`;
        const collapseId = `collapse-${index}`;
        const isSystemTable = table.name.startsWith('t_');
        const tableType = isSystemTable ? 'system' : 'data';

        html += `
            <div class="schema-table" data-table-type="${tableType}" data-table-name="${table.name.toLowerCase()}">
                <div class="schema-table-header" onclick="toggleTableContent('${collapseId}', this)">
                    <div class="schema-table-name">
                        <i class="schema-table-icon ${isSystemTable ? 'system-table' : 'data-table'}"></i>
                        ${table.name}
                    </div>
                    <div class="schema-table-info">
                        <span class="schema-table-columns-count">${table.columns.length} 列</span>
                        <i class="schema-table-arrow"></i>
                    </div>
                </div>
                <div id="${collapseId}" class="schema-table-content">
                    <div class="schema-table-columns">
                        <table>
                            <thead>
                                <tr>
                                    <th class="col-name">列名</th>
                                    <th class="col-type">类型</th>
                                    <th class="col-desc">属性</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${table.columns.map(column => {
                                    const isPrimaryKey = column.description.includes('主键');
                                    const isNullable = column.description.includes('可为空');
                                    return `
                                        <tr>
                                            <td class="col-name ${isPrimaryKey ? 'primary-key' : ''}">
                                                ${column.name}
                                                ${isPrimaryKey ? '<i class="key-icon" title="主键"></i>' : ''}
                                            </td>
                                            <td class="col-type">
                                                <span class="type-badge">${formatColumnType(column.type)}</span>
                                            </td>
                                            <td class="col-desc">
                                                ${isPrimaryKey ? '<span class="badge primary-key-badge">主键</span>' : ''}
                                                ${isNullable ? '<span class="badge nullable-badge">可空</span>' : '<span class="badge not-nullable-badge">非空</span>'}
                                            </td>
                                        </tr>
                                    `;
                                }).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    });

    html += '</div>';

    schemaAccordion.innerHTML = html;

    // 添加搜索功能
    const schemaSearch = document.getElementById('schemaSearch');
    if (schemaSearch) {
        schemaSearch.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const tables = document.querySelectorAll('.schema-table');

            tables.forEach(table => {
                const tableName = table.getAttribute('data-table-name');
                if (tableName.includes(searchTerm)) {
                    table.style.display = '';
                } else {
                    table.style.display = 'none';
                }
            });
        });
    }

    // 添加标签过滤功能
    const schemaTabs = document.querySelectorAll('.schema-tab');
    if (schemaTabs.length > 0) {
        schemaTabs.forEach(tab => {
            tab.addEventListener('click', function() {
                // 移除所有标签的活动状态
                schemaTabs.forEach(t => t.classList.remove('active'));

                // 添加当前标签的活动状态
                this.classList.add('active');

                // 获取过滤条件
                const filter = this.getAttribute('data-filter');

                // 过滤表
                const tables = document.querySelectorAll('.schema-table');
                tables.forEach(table => {
                    const tableType = table.getAttribute('data-table-type');
                    if (filter === 'all' || tableType === filter) {
                        table.style.display = '';
                    } else {
                        table.style.display = 'none';
                    }
                });
            });
        });
    }
}

// 切换表内容显示/隐藏
function toggleTableContent(contentId, headerElement) {
    const contentElement = document.getElementById(contentId);
    headerElement.classList.toggle('expanded');
    contentElement.classList.toggle('show');
}

// 格式化列类型
function formatColumnType(type) {
    // 提取基本类型
    let baseType = type.split('(')[0].toLowerCase();

    // 根据类型返回不同的格式
    switch (baseType) {
        case 'int':
        case 'bigint':
        case 'smallint':
        case 'tinyint':
            return `<span class="type-int">${type}</span>`;
        case 'varchar':
        case 'char':
        case 'text':
        case 'longtext':
            return `<span class="type-string">${type}</span>`;
        case 'decimal':
        case 'float':
        case 'double':
            return `<span class="type-number">${type}</span>`;
        case 'date':
        case 'datetime':
        case 'timestamp':
            return `<span class="type-date">${type}</span>`;
        case 'boolean':
        case 'bool':
            return `<span class="type-boolean">${type}</span>`;
        default:
            return `<span class="type-other">${type}</span>`;
    }
}

// 添加系统消息
function addSystemMessage(message, className = '', results = null) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `chat-message system-message ${className}`;
    
    // 如果消息包含结果数据，添加查看结果按钮
    if (results) {
        const viewResultsBtn = document.createElement('button');
        viewResultsBtn.className = 'btn btn-sm btn-outline-primary mt-2';
        viewResultsBtn.textContent = '查看结果';
        viewResultsBtn.onclick = () => {
            resultModal.show(results);
        };
        
        // 将消息内容和按钮包装在一个容器中
        const contentContainer = document.createElement('div');
        contentContainer.innerHTML = message;
        contentContainer.appendChild(viewResultsBtn);
        
        messageDiv.appendChild(contentContainer);
    } else {
        messageDiv.innerHTML = message;
    }
    
    chatHistory.appendChild(messageDiv);
    chatHistory.scrollTop = chatHistory.scrollHeight;
}

// 处理查询提交
async function handleQuerySubmit(event) {
    event.preventDefault();

    const query = queryInput.value.trim();
    if (!query) return;

    // 添加用户消息
    addUserMessage(query);

    // 清空输入框
    queryInput.value = '';

    // 显示加载中
    addSystemMessage('<div class="spinner-border" role="status"></div> 正在处理您的查询...', 'loading-message');

    try {
        const response = await fetch(`${API_URL}/nl2sql`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                query: query,
                get_schema: true,
                execute: executeQuery.checked
            })
        });

        const data = await response.json();

        // 移除加载消息
        document.querySelector('.loading-message')?.remove();

        if (data.success) {
            // 显示SQL和解释
            let sqlForDisplay = data.sql.replace(/</g, '&lt;').replace(/>/g, '&gt;');
            let message = `<p><strong>生成的SQL:</strong></p>
                          <div class="sql-code">${sqlForDisplay}</div>
                          <p><strong>解释:</strong> ${data.explanation}</p>`;

            // 如果执行了查询
            if (executeQuery.checked && data.results) {
                // 显示结果模态框
                resultModal.show(data.results);
                // 添加系统消息，并传入结果数据
                addSystemMessage(message, '', data.results);
            } else {
                addSystemMessage(message);
            }
        } else {
            addSystemMessage(`<p>处理查询时出错: ${data.error}</p>`);
        }
    } catch (error) {
        console.error('发送查询失败:', error);
        document.querySelector('.loading-message')?.remove();
        addSystemMessage(`<p>发送查询失败: ${error.message}</p>`);
    }
}

// 添加用户消息
function addUserMessage(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'chat-message user-message';
    messageDiv.innerHTML = `<p>${message}</p>`;
    chatHistory.appendChild(messageDiv);
    chatHistory.scrollTop = chatHistory.scrollHeight;
}

// SQL语法高亮
function highlightSQL(element) {
    if (!element) return;

    let sql = element.textContent;

    // 创建一个临时元素来存储高亮后的SQL
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = sql;

    // 关键字高亮
    const keywords = ['SELECT', 'FROM', 'WHERE', 'GROUP BY', 'ORDER BY', 'HAVING', 'JOIN', 'LEFT JOIN', 'RIGHT JOIN', 'INNER JOIN', 'OUTER JOIN', 'ON', 'AS', 'AND', 'OR', 'NOT', 'IN', 'BETWEEN', 'LIKE', 'IS NULL', 'IS NOT NULL', 'COUNT', 'SUM', 'AVG', 'MAX', 'MIN', 'LIMIT', 'OFFSET', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'ALTER', 'DROP', 'TABLE', 'INDEX', 'VIEW', 'PROCEDURE', 'FUNCTION', 'TRIGGER', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'DISTINCT', 'ALL', 'ANY', 'UNION', 'INTERSECT', 'EXCEPT', 'DESC', 'ASC'];

    // 函数高亮
    const functions = ['COUNT', 'SUM', 'AVG', 'MAX', 'MIN', 'CONCAT', 'SUBSTRING', 'TRIM', 'UPPER', 'LOWER', 'DATE_FORMAT', 'NOW', 'DATEDIFF', 'IF', 'IFNULL', 'COALESCE', 'CAST', 'CONVERT'];

    // 先处理字符串，避免关键字在字符串中被高亮
    sql = sql.replace(/('[^']*')/g, '<span class="string">$1</span>');

    // 处理关键字
    keywords.forEach(keyword => {
        const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
        sql = sql.replace(regex, match => {
            // 检查是否在字符串标签内
            if (/<span class="string">.*?\b${match}\b.*?<\/span>/i.test(sql)) {
                return match;
            }
            return `<span class="keyword">${match}</span>`;
        });
    });

    // 处理函数
    functions.forEach(func => {
        const regex = new RegExp(`\\b${func}\\s*\\(`, 'gi');
        sql = sql.replace(regex, match => {
            // 检查是否在字符串标签内
            if (/<span class="string">.*?\b${match.slice(0, -1)}\b.*?<\/span>/i.test(sql)) {
                return match;
            }
            return `<span class="function">${match.slice(0, -1)}</span>(`;
        });
    });

    // 处理数字
    sql = sql.replace(/\b(\d+)\b/g, (match, p1, offset) => {
        // 检查是否在字符串标签内
        const beforeMatch = sql.substring(0, offset);
        const openTags = (beforeMatch.match(/<span class="string">/g) || []).length;
        const closeTags = (beforeMatch.match(/<\/span>/g) || []).length;
        if (openTags > closeTags) {
            return match;
        }
        return `<span class="number">${match}</span>`;
    });

    // 处理运算符
    sql = sql.replace(/([=<>!]+)/g, (match, p1, offset) => {
        // 检查是否在字符串标签内
        const beforeMatch = sql.substring(0, offset);
        const openTags = (beforeMatch.match(/<span class="string">/g) || []).length;
        const closeTags = (beforeMatch.match(/<\/span>/g) || []).length;
        if (openTags > closeTags) {
            return match;
        }
        return `<span class="operator">${match}</span>`;
    });

    element.innerHTML = sql;
}

// 显示结果
function displayResults(data) {
    if (!data || data.length === 0) {
        resultContent.innerHTML = '<div class="alert alert-warning">没有可用的结果数据</div>';
        return;
    }

    // 创建表格
    const table = document.createElement('table');
    table.className = 'table table-striped';
    // 将结果数据存储在表格的 dataset 中
    table.dataset.results = JSON.stringify(data);
    
    // 添加表头
    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    Object.keys(data[0]).forEach(key => {
        const th = document.createElement('th');
        th.textContent = key;
        headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);
    
    // 添加数据行
    const tbody = document.createElement('tbody');
    data.forEach(row => {
        const tr = document.createElement('tr');
        Object.values(row).forEach(value => {
            const td = document.createElement('td');
            td.textContent = value;
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    
    // 清空并添加表格
    resultContent.innerHTML = '';
    resultContent.appendChild(table);
    
    // 初始化图表
    setTimeout(() => {
        if (typeof Chart !== 'undefined') {
            initChart(data, 'bar');
        } else {
            console.error('Chart.js 未加载');
        }
    }, 100);
}

// 初始化图表
function initChart(data, type = 'bar') {
    try {
        const ctx = document.getElementById('resultChart');
        if (!ctx) {
            console.error('找不到图表容器元素');
            return;
        }

        // 如果已存在图表，先销毁
        if (currentChart) {
            currentChart.destroy();
        }

        // 准备图表数据
        const chartData = prepareChartData(data, type);
        if (!chartData) {
            console.error('无法准备图表数据');
            return;
        }
        
        // 创建新图表
        currentChart = new Chart(ctx.getContext('2d'), {
            type: type,
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: '查询结果可视化'
                    }
                }
            }
        });
    } catch (error) {
        console.error('初始化图表失败:', error);
    }
}

// 准备图表数据
function prepareChartData(data, type) {
    try {
        if (!data || data.length === 0) {
            console.error('没有数据可供图表显示');
            return null;
        }

        // 获取第一行数据作为示例
        const firstRow = data[0];
        const keys = Object.keys(firstRow);
        
        if (keys.length < 2) {
            console.error('数据列数不足，无法创建图表');
            return null;
        }
        
        // 默认使用第一列作为标签，第二列作为数据
        const labels = data.map(row => row[keys[0]]);
        const values = data.map(row => row[keys[1]]);

        return {
            labels: labels,
            datasets: [{
                label: keys[1],
                data: values,
                backgroundColor: type === 'pie' 
                    ? generateColors(values.length)
                    : 'rgba(75, 192, 192, 0.6)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        };
    } catch (error) {
        console.error('准备图表数据失败:', error);
        return null;
    }
}

// 生成颜色数组
function generateColors(count) {
    const colors = [];
    for (let i = 0; i < count; i++) {
        colors.push(`hsl(${(i * 360) / count}, 70%, 50%)`);
    }
    return colors;
}

// 处理查询
async function handleQuery(query) {
    try {
        const response = await fetch('/api/nl2sql', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                query: query,
                get_schema: true,
                execute: true
            })
        });

        const result = await response.json();
        
        if (result.success) {
            // 显示SQL和解释
            addToChatHistory('user', query);
            addToChatHistory('assistant', `生成的SQL: ${result.sql}\n\n解释: ${result.explanation}`);
            
            // 显示结果
            if (result.results) {
                displayResults(result.results);
                // 显示模态框
                const modal = new bootstrap.Modal(document.getElementById('resultModal'));
                modal.show();
            }
        } else {
            addToChatHistory('assistant', `错误: ${result.error}`);
        }
    } catch (error) {
        console.error('Error:', error);
        addToChatHistory('assistant', `发生错误: ${error.message}`);
    }
}

// 添加消息到聊天历史
function addToChatHistory(role, content) {
    const chatHistory = document.getElementById('chatHistory');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}-message`;
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.innerHTML = marked.parse(content);
    
    messageDiv.appendChild(contentDiv);
    chatHistory.appendChild(messageDiv);
    chatHistory.scrollTop = chatHistory.scrollHeight;
}

// 初始化事件监听
document.addEventListener('DOMContentLoaded', () => {
    // 查询表单提交
    const queryForm = document.getElementById('queryForm');
    queryForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const queryInput = document.getElementById('queryInput');
        const query = queryInput.value.trim();
        if (query) {
            handleQuery(query);
            queryInput.value = '';
        }
    });

    // 刷新表结构
    const refreshSchema = document.getElementById('refreshSchema');
    refreshSchema.addEventListener('click', async () => {
        try {
            const response = await fetch('/api/schema');
            const result = await response.json();
            if (result.success) {
                updateSchemaDisplay(result.schema);
            }
        } catch (error) {
            console.error('Error refreshing schema:', error);
        }
    });
});

// 更新表结构显示
function updateSchemaDisplay(schema) {
    const schemaContainer = document.getElementById('schemaAccordion');
    schemaContainer.innerHTML = '';
    
    schema.forEach(table => {
        const tableDiv = document.createElement('div');
        tableDiv.className = 'accordion-item';
        
        const header = document.createElement('h2');
        header.className = 'accordion-header';
        
        const button = document.createElement('button');
        button.className = 'accordion-button collapsed';
        button.setAttribute('data-bs-toggle', 'collapse');
        button.setAttribute('data-bs-target', `#table-${table.name}`);
        button.textContent = table.name;
        
        header.appendChild(button);
        
        const collapse = document.createElement('div');
        collapse.id = `table-${table.name}`;
        collapse.className = 'accordion-collapse collapse';
        
        const body = document.createElement('div');
        body.className = 'accordion-body';
        
        const columnsList = document.createElement('ul');
        table.columns.forEach(column => {
            const li = document.createElement('li');
            li.textContent = `${column.name} (${column.type})${column.description ? ` - ${column.description}` : ''}`;
            columnsList.appendChild(li);
        });
        
        body.appendChild(columnsList);
        collapse.appendChild(body);
        
        tableDiv.appendChild(header);
        tableDiv.appendChild(collapse);
        schemaContainer.appendChild(tableDiv);
    });
}
